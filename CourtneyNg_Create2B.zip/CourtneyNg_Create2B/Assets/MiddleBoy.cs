﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MiddleBoy : MonoBehaviour {
    public float timer;
    public Vector3 bulletPos;
    public GameObject bulletPrefab;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
        timer += Time.deltaTime;

        //every 3 seconds enemy shoot bullet
        if(timer >= 3){
            bulletPos = GetComponent<Transform>().position;
            Instantiate(bulletPrefab, bulletPos, Quaternion.identity);
            timer = 0;
        }   
	}
}
