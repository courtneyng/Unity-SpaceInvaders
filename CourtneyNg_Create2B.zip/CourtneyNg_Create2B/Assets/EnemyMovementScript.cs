﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovementScript : MonoBehaviour {
    //public float timer;
    public int facing = 0;
    public Vector3 leftMovement;
    public Vector3 rightMovement;
    public Vector3 downMovement;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //timer += Time.deltaTime;
        //GetComponent<Transform>().position += downMovement;
        //0 = left
        //1 = right
        //need to find a way to account for the ones if i decide to put the enemies
        //into a formation otherwise some will not hit -5.9 or 5.9 and will be stuck

        /*
         * position.x grabs just the x int the 3 float vector
         * between -8 and 8 (the approx walls of the scene)
         */ 
        if(-8 < GetComponent<Transform>().position.x && GetComponent<Transform>().position.x < 8 && facing == 0){
            //facing 0 is left so when it is 0 it moves left
            GetComponent<Transform>().position += leftMovement;

            //change the facing so it can go in the opposite direction
            //-7.9 is almost -8 good enough to change so less hassle
            if(GetComponent<Transform>().position.x <= -7.9){
                facing++;
                //move down when it hits this point as well
                GetComponent<Transform>().position += downMovement;
            }

        }

        //facing = 1, go in the opposite direction
        else if(-8 < GetComponent<Transform>().position.x && GetComponent<Transform>().position.x < 8 && facing == 1){
            GetComponent<Transform>().position += rightMovement;
            if (GetComponent<Transform>().position.x >= 7.9)
            {
                facing--;
                GetComponent<Transform>().position += downMovement;
            }
        }

        //when the enemy reaches a y position of -4.5 player loses
        if(GetComponent<Transform>().position.y <= -4.5){
            Debug.Log("you lose");
            Destroy(gameObject);
        }
	}

	private void OnCollisionEnter2D(Collision2D collision)
	{
        //when it hits the house DESTROYS IT
        if (collision.gameObject.tag == "House")
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
	}
}
