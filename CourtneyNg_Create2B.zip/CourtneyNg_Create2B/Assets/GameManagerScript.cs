﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript : MonoBehaviour {
    public float timer;
    public Vector3[] enemyPos;
    public Vector3[] housePos;
    public GameObject enemyPrefab;
    public GameObject fleetPrefab;
    public GameObject nextfleet;
    public GameObject housePrefab;
	// Use this for initialization
	void Start () {
        
        for (int i = 0; i < 4; i++){
            Instantiate(housePrefab, housePos[i], Quaternion.identity);
        }

	}
	
	// Update is called once per frame
	void Update () {
        timer += Time.deltaTime;
        /*
        if (timer >= 3){
            for (int i = 0; i < 1; i++)
            {
                Instantiate(enemyPrefab, enemyPos[i], Quaternion.identity);
            }
            timer = 0;
        }
        */

        /*
         * checks if the fleet is on the screen
         * checks if the childcount is 0
         * which would then destroy the container holding it all
         * so that it can spawn a new fleet once all the children are
         * d e s t r o y e d
         */
        if(nextfleet != null && nextfleet.GetComponent<Transform>().childCount == 0){
            Destroy(nextfleet);
        }

        /*
         * checks if the fleet isnt there
         * spawns a new one
         */
        if(nextfleet == null){
            nextfleet = Instantiate(enemyPrefab, enemyPos[0], Quaternion.identity);
        }
	}
}
