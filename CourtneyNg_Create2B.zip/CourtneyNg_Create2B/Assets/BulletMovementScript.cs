﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletMovementScript : MonoBehaviour {
    public Vector3 bulletMovement;
    public float timer;

	// Use this for initialization
	void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {

        GetComponent<Transform>().position += bulletMovement;
        if (gameObject.tag == "Bullet")
        {
            //destroy bullet after a certain amount of time
            timer += Time.deltaTime;
            if (timer >= 1)
            {
                Destroy(gameObject);
            }
        }
    }

    //when it hits enemy or house DESTROY
	private void OnCollisionEnter2D(Collision2D collision){
        if(collision.gameObject.tag == "Enemy"){
            //gameManagerObject.GetComponent<GameManagerScript>().score += 1;
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
        if (collision.gameObject.tag == "House")
        {
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
	}

}
