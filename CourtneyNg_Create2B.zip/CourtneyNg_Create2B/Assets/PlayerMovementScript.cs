﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementScript : MonoBehaviour {
    public float timer;
    public Vector3 rightMovement;
    public Vector3 leftMovement;
    public Vector3 bulletPos;
    public GameObject bulletPrefab;
    public GameObject currentBullet;


	// Use this for initialization
	void Start () {
		//bullet -4.072
	}
	
	// Update is called once per frame
	void Update () {
        //timer for stretch goal
        timer += Time.deltaTime;

        //right movement
        if(Input.GetKey(KeyCode.RightArrow)){
            GetComponent<Transform>().position += rightMovement;
        }

        //left movement
        if(Input.GetKey(KeyCode.LeftArrow)){
            GetComponent<Transform>().position += leftMovement;
        }

        /*
         * when you hold space bar, you can't spam
         * also for only having one bullet on the screen
         * so if current bullet is not there (null) 
         * spawn a new one
         */
        if(Input.GetKey(KeyCode.Space) && currentBullet == null){
            bulletPos = GetComponent<Transform>().position;
            currentBullet = Instantiate(bulletPrefab, bulletPos, Quaternion.identity);

        }

        //if game object is not null (on the screen)
        //and if timer passes 30 seconds
        //you win
        if(gameObject != null && timer >= 30){
            Debug.Log("you win");
        }
	}

    //when the player and enemy collide you lose
    //when enemy bullet and player collide you lose
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            Debug.Log("you lose");
            Destroy(gameObject);
        }
        if(collision.gameObject.tag == "EnemyBullet"){
            Debug.Log("you lose");
            Destroy(gameObject);
        }
    }
}
