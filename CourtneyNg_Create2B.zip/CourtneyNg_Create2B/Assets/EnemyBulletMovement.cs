﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletMovement : MonoBehaviour {
    public Vector3 downMovement;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        GetComponent<Transform>().position += downMovement;

        //if the bullet passes -5 destroy bullet, get rid of excess 
        if(GetComponent<Transform>().position.y <= -5){
            Destroy(gameObject);
        }
	}

	private void OnCollisionEnter2D(Collision2D collision)
	{
        /*
         * when enemy bullet hit brick (which is apart of the house)
         * destroy the bullet and the house
        */
        if(collision.gameObject.tag == "House"){
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
	}
}
